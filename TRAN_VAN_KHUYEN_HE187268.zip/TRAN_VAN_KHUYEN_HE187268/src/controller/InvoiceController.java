package controller;

import model.avltree.AVLTree;
import model.entities.Customer;
import model.entities.IceCream;
import model.entities.Invoice;
import utils.IDGenerator;
import view.ConsoleView;
import view.ice_cream.IceCreamView;
import view.invoice.InvoiceView;

import java.util.ArrayList;
import java.util.Scanner;

public class InvoiceController {
    Scanner scanner = new Scanner(System.in);
    ConsoleView mainView = new ConsoleView();
    InvoiceView invoiceView = new InvoiceView();
    IceCreamView iceCreamView = new IceCreamView();
    IDGenerator idGenerator = new IDGenerator();

    CustomerController customerController;
    IceCreamController iceCreamController;

    public InvoiceController () {
        this.customerController = new CustomerController();
        this.iceCreamController = new IceCreamController();
    }

    public void start() {
        while (true) {
            invoiceView.displayInvoiceMenu();
            int choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    this.createInvoice();
                    break;
                case 2:
                    return;
                default:
                    mainView.displayMessage("Enter 1 or 2");
            }
        }
    }

    public void createInvoice() {
        boolean isSave = true;
        while(true) {
            mainView.displayMessage("Does customer want to save information? (Y/N)");
            String choice = scanner.nextLine();
            if(choice.equalsIgnoreCase("n")) {
                isSave = false;
                break;
            }
            if(choice.equalsIgnoreCase("y")) {
                break;
            }
            mainView.displayMessage("Enter Y or N");
        }

        if(!isSave) {
            return;
        }

        AVLTree<Customer> customers = customerController.customers;
        mainView.displayInputMessage("customer phone");
        String cusPhone = scanner.nextLine();
        boolean isCustomerExisted = customers.isNodeExisted(new Customer(cusPhone));
        Customer currentCustomer;
        if(!isCustomerExisted) {
            currentCustomer = customerController.createNewCustomer(cusPhone);

        } else {
            currentCustomer = customerController.customers.getNode(customers.root, new Customer(cusPhone));
        }

        addInvoice(currentCustomer);
    }

    public void addInvoice (Customer customer) {

        ArrayList<IceCream> iceCreams = iceCreamController.getAllIceCream();

        mainView.displayMessage("Ice Cream list =============");
        iceCreamView.displayIceCreamArray(iceCreams);

        mainView.displayInputMessage("ice cream index");
        int index = Integer.parseInt(scanner.nextLine());
        mainView.displayInputMessage("quantity");
        int quantity = Integer.parseInt(scanner.nextLine());

        String invoiceID = idGenerator.generateInvoiceID();
        Invoice newInvoice = new Invoice(invoiceID, customer.getCustomerPhone());

        for(int i = 0; i < quantity; i++) {
            newInvoice.addItem(iceCreams.get(index));
        }

        System.out.println("");
        mainView.displayMessage("Your invoice -------");
        System.out.println(newInvoice.toString());
    }


}
