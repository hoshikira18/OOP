package model.dao;

public class InvoiceDAO {

}
