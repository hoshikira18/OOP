package model.storage;

public class InvoiceStorage {
}
