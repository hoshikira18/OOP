package view.invoice;

public class InvoiceView {
    public void displayInvoiceMenu () {
        System.out.println("");
        System.out.println("===== MIXUE INVOICE =====");
        System.out.println("1. Create new Invoice");
        System.out.println("2. Exit");
        System.out.println("Chose from 1-2");
    }
}
